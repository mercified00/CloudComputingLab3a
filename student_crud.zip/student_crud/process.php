<?php
include('connect.php');
if (isset($_POST["create"])) {
    $studName = mysqli_real_escape_string($conn, $_POST["studName"]);
    $studID = mysqli_real_escape_string($conn, $_POST["studID"]);
    $major = mysqli_real_escape_string($conn, $_POST["major"]);
    $bio = mysqli_real_escape_string($conn, $_POST["bio"]);
    $sqlInsert = "INSERT INTO students(studName , studID , major , bio) VALUES ('$studName','$studID','$major', '$bio')";
    if(mysqli_query($conn,$sqlInsert)){
        session_start();
        $_SESSION["create"] = "Student Added Successfully!";
        header("Location:index.php");
    }else{
        die("Something went wrong");
    }
}
if (isset($_POST["edit"])) {
    $studName = mysqli_real_escape_string($conn, $_POST["studName"]);
    $studID = mysqli_real_escape_string($conn, $_POST["studID"]);
    $major = mysqli_real_escape_string($conn, $_POST["major"]);
    $bio = mysqli_real_escape_string($conn, $_POST["bio"]);
    $id = mysqli_real_escape_string($conn, $_POST["id"]);
    $sqlUpdate = "UPDATE students SET studName = '$studName', studID = '$studID', major = '$major', bio = '$bio' WHERE id='$id'";
    if(mysqli_query($conn,$sqlUpdate)){
        session_start();
        $_SESSION["update"] = "Student Updated Successfully!";
        header("Location:index.php");
    }else{
        die("Something went wrong");
    }
}

$result = mysqli_query($conn, $sqlInsert);

if ($result) {
    echo "New record created successfully";
} else {
    echo "Error: " . mysqli_error($conn);
}

?>