<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>Edit Student</title>
</head>
<body>
    <div class="container my-5">
    <header class="d-flex justify-content-between my-4">
            <h1>Edit Student</h1>
            <div>
            <a href="index.php" class="btn btn-primary">Back</a>
            </div>
        </header>
        <form action="process.php" method="post">
            <?php 
            
            if (isset($_GET['id'])) {
                include("connect.php");
                $id = $_GET['id'];
                $sql = "SELECT * FROM students WHERE id=$id";
                $result = mysqli_query($conn,$sql);
                $row = mysqli_fetch_array($result);
                ?>
                     <div class="form-elemnt my-4">
                <input type="text" class="form-control" name="studName" placeholder="Student Name:" value="<?php echo $row["studName"]; ?>">
            </div>
            <div class="form-elemnt my-4">
                <input type="text" class="form-control" name="studID" placeholder="Student ID:" value="<?php echo $row["studID"]; ?>">
            </div>
            <div class="form-elemnt my-4">
                <select name="major" id="" class="form-control">
                    <option value="">Select Student Major:</option>
                    <option value="Computer Science" <?php if($row["major"]=="Computer Science"){echo "selected";} ?>>Computer Science</option>
                    <option value="Business Administration" <?php if($row["major"]=="Business Administration"){echo "selected";} ?>>Business Administration</option>
                    <option value="Engineering" <?php if($row["major"]=="Engineering"){echo "selected";} ?>>Engineering</option>
                    <option value="Law" <?php if($row["major"]=="Law"){echo "selected";} ?>>Law</option>
                </select>
            </div>
            <div class="form-element my-4">
                <textarea name="bio" id="" class="form-control" placeholder="Student Bio:"><?php echo $row["bio"]; ?></textarea>
            </div>
            <input type="hidden" value="<?php echo $id; ?>" name="id">
            <div class="form-element my-4">
                <input type="submit" name="edit" value="Edit Student" class="btn btn-primary">
            </div>
                <?php
            }else{
                echo "<h3> Student Does Not Exist In records</h3>";
            }
            ?>
           
        </form>
        
        
    </div>
</body>
</html>