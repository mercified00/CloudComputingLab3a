<?php
$dbHost = "localhost";
$dbUser = "root";
$dbPass = "giftedkid2015";
$dbName = "crud";
$conn = mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);
if (!$conn) {
    die("Something went wrong");
}
?>